﻿using System.ComponentModel.DataAnnotations;

namespace Restaurante.API.Modelos // Asegúrate de que este espacio de nombres esté presente
{
    public class Contacto
    {
        [Key]
        public int IdContacto { get; set; }

        [Required]
        [StringLength(50)]
        public string Nombres { get; set; } = string.Empty;

        [Required]
        [StringLength(50)]
        public string Apellidos { get; set; } = string.Empty;

        [Required]
        [StringLength(15)]
        public string Telefono { get; set; } = string.Empty;

        [Required]
        [EmailAddress]
        [StringLength(100)]
        public string Correo { get; set; } = string.Empty;
    }
}

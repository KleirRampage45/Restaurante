﻿namespace Restaurante.API.Entidades
{
    public class Clientes 
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Sobrenombree { get; set; }
        public DateTime FechaNacimiento
        { get; set; }
      
        public string Telefono { get; set; }
        public string Email { get; set; }

    }
}

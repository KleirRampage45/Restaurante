﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Restaurante.API;
using Restaurante.API.Entidades;
using Microsoft.AspNetCore.Hosting;

namespace Restaurante.API
{
    public class ApplicationDbContext: DbContext
    {
        public ApplicationDbContext(DbContextOptions options) :base(options)
    {

    }
        public DbSet<Clientes> Clientes { get; set; }
    }
}
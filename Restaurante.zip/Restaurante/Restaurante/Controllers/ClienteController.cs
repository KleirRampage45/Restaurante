﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Restaurante.API;
using Restaurante.API.Entidades;
using Microsoft.AspNetCore.Hosting;

namespace Restaurante.API.Controllers
{
    [ApiController]
    [Route("api/clientes")]
    public class ClienteController : Controller
    {

        private readonly ApplicationDbContext _context;
        public ClienteController(ApplicationDbContext context)
        {
            this._context = context;
        }
        [HttpGet]
        public async Task<ActionResult<List<Clientes>>> Get()
        {
            return await _context.Clientes.ToListAsync();
        }
        [HttpPost]
        public async Task<ActionResult> Post(Clientes clientes)
        {
            var existeNombreCliente = await _context.Clientes.AnyAsync(x => x.Nombre == clientes.Nombre);
            if (existeNombreCliente)
            {
                return BadRequest($"Ya existe cliente con el nombre {clientes.Nombre}");
            }
            _context.Add(clientes);
            await _context.SaveChangesAsync();
            return Ok();
        }
        [HttpPut("{Id:int}")]
        public async Task<ActionResult> Put(Clientes clientes, int Id)
        {
            if (clientes.Id != Id)
            {
                return BadRequest("El id no coincide");
            }
            var existe = await _context.Clientes.AnyAsync(x => x.Id == Id);
            if (!existe)
            {
                return NotFound();
            }
            _context.Update(clientes);
            await _context.SaveChangesAsync();
            return Ok();
        }
        [HttpDelete("{Id:int}")]
        public async Task<ActionResult> Delete(int Id)
        {

            var existe = await _context.Clientes.AnyAsync(x => x.Id == Id);
            if (!existe)
            {
                return NotFound();
            }
            _context.Remove(new Clientes() {Id=Id });
            await _context.SaveChangesAsync();
            return Ok();

        }
    }
}

        
    


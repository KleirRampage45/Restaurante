﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration; // Asegúrate de incluir este using
using Restaurante.API.Modelos;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace Restaurante.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContactoController : ControllerBase
    {
        private readonly string _connectionString;

        // Inyecta IConfiguration en el constructor
        public ContactoController(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("ContactDBConnectionString");
        }

        [HttpPost]
        public IActionResult CrearContacto([FromBody] Contacto contacto)
        {
            if (contacto == null)
            {
                return BadRequest("El contacto no puede ser nulo.");
            }

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_InsertarContacto", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Nombres", contacto.Nombres);
                    cmd.Parameters.AddWithValue("@Apellidos", contacto.Apellidos);
                    cmd.Parameters.AddWithValue("@Telefono", contacto.Telefono);
                    cmd.Parameters.AddWithValue("@Correo", contacto.Correo);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return CreatedAtAction(nameof(ObtenerContactoPorId), new { id = contacto.IdContacto }, contacto);
        }

        [HttpGet]
        public IActionResult ObtenerContactos()
        {
            var contactos = new List<Contacto>();

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ObtenerContactos", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var contacto = new Contacto
                            {
                                IdContacto = reader.GetInt32(0),
                                Nombres = reader.GetString(1),
                                Apellidos = reader.GetString(2),
                                Telefono = reader.GetString(3),
                                Correo = reader.GetString(4)
                            };
                            contactos.Add(contacto);
                        }
                    }
                }
            }

            return Ok(contactos);
        }

        [HttpGet("{id}")]
        public IActionResult ObtenerContactoPorId(int id)
        {
            Contacto contacto = null;

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ObtenerContactoPorId", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@IdContacto", id);

                    conn.Open();
                    using (SqlDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            contacto = new Contacto
                            {
                                IdContacto = reader.GetInt32(0),
                                Nombres = reader.GetString(1),
                                Apellidos = reader.GetString(2),
                                Telefono = reader.GetString(3),
                                Correo = reader.GetString(4)
                            };
                        }
                    }
                }
            }

            return contacto != null ? Ok(contacto) : NotFound();
        }

        [HttpPut("{id}")]
        public IActionResult ActualizarContacto(int id, [FromBody] Contacto contacto)
        {
            if (contacto == null || id != contacto.IdContacto)
            {
                return BadRequest("El contacto no puede ser nulo y el ID debe coincidir.");
            }

            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_ActualizarContacto", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@IdContacto", contacto.IdContacto);
                    cmd.Parameters.AddWithValue("@Nombres", contacto.Nombres);
                    cmd.Parameters.AddWithValue("@Apellidos", contacto.Apellidos);
                    cmd.Parameters.AddWithValue("@Telefono", contacto.Telefono);
                    cmd.Parameters.AddWithValue("@Correo", contacto.Correo);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }

            return NoContent(); // Devuelve 204 No Content
        }

        [HttpDelete("{id}")]
        public IActionResult EliminarContacto(int id)
        {
            using (SqlConnection conn = new SqlConnection(_connectionString))
            {
                using (SqlCommand cmd = new SqlCommand("sp_EliminarContacto", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@IdContacto", id);

                    conn.Open();
                    var rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected == 0)
                    {
                        return NotFound();
                    }
                }
            }

            return NoContent(); // Devuelve 204 No Content
        }
    }
}

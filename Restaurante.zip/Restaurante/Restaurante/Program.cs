using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Restaurante.API;
using Restaurante.API.Entidades;
using Microsoft.AspNetCore.Hosting;

var builder = WebApplication.CreateBuilder(args);
var startup = new Menu(builder.Configuration);
startup.ConfigureServices(builder.Services);
var app = builder.Build();
startup.Configure(app, app.Environment);
app.Run();
